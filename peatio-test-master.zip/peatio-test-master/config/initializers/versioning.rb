# encoding: UTF-8
# frozen_string_literal: true
# This file is auto-generated from the current state of VCS.
# Instead of editing this file, please use bin/gendocs.

module Peatio
  class Application
    GIT_TAG =    '3.1.0'
    GIT_SHA =    '36895e2'
    BUILD_DATE = '2021-07-04 11:43:58+00:00'
    VERSION =    GIT_TAG
  end
end
